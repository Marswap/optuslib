from enum import Enum


class DexType(str, Enum):
    ROUTER_BASED = "router_based"
