from enum import Enum


class Currency(str, Enum):
    TON = "TON"
    USD = "USD"
