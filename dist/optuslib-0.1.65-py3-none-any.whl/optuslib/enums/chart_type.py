from enum import Enum, auto


class ChartType(Enum):
    USD_LIQUIDITY = auto()
    USD_VOLUME = auto()
    PRICE = auto()
