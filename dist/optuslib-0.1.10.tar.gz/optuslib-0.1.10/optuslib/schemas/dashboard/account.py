from pydantic import BaseModel


class DashboardBaseAccount(BaseModel):
    pass


class DashboardAccount(DashboardBaseAccount):
    pass
