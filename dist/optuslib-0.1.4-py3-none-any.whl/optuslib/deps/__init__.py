from .fast_storage import get_fast_storage
