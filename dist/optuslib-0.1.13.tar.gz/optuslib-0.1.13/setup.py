# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['optuslib',
 'optuslib.deps',
 'optuslib.schemas',
 'optuslib.schemas.dashboard',
 'optuslib.schemas.dashboard.db',
 'optuslib.storages']

package_data = \
{'': ['*']}

install_requires = \
['aioredis>=2.0.1,<3.0.0', 'pydantic==1.10.9']

setup_kwargs = {
    'name': 'optuslib',
    'version': '0.1.13',
    'description': 'Python library for OPTUS projects',
    'long_description': 'None',
    'author': 'Aleksandr Kaekhtin',
    'author_email': 'kaehtin.aa@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
