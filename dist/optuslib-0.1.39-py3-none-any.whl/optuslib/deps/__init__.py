from .fast_storage import create_fast_storage
